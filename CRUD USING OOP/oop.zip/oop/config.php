<?php 
const DBSERVER = "localhost";
const DBUSER   = "root";
const DBPASS   = "";
const DBNAME   = "eshop";